/**
 * Created by aniquedavla on 12/21/16.
 */
public class Node {
    int key;
    int weight;

    public Node(int key, int weight) {
        this.key = key;
        this.weight = weight;
    }
}
