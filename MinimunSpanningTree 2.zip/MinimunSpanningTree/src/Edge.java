/**
 * Created by aniquedavla on 12/21/16.
 */
public class Edge {
    int src;
    int dest;
    int weight;

    public Edge(int src, int dest, int weight){
        this.src = src;
        this.dest = dest;
        this.weight = weight;
    }

}
